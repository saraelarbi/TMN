/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.esprit.tests;

import edu.esprit.entities.Commande;
import edu.esprit.utils.MyConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.SortEvent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author ASUS CELERON
 */
public class Commande_GestionController implements Initializable {

    @FXML
    private AnchorPane Anchor_CMD;
    @FXML
    private TextField TextField_num;
    @FXML
    private TextField TextField_total;
    @FXML
    private TextField TextField_qtite;
    @FXML
    private TextField TextField_idu;
    @FXML
    private TextField TextField_idp;
    @FXML
    private TableView<Commande> Affichage_cmd;
    @FXML
    private TableColumn<Commande, Integer> numCMD;
    @FXML
    private TableColumn<Commande, Float> total;
    @FXML
    private TableColumn<Commande, String> qtite;
    @FXML
    private TableColumn<Commande, Integer> idUser;
    @FXML
    private TableColumn<Commande, Integer> idProduit;
    @FXML
    private Button btnAjouter;
    @FXML
    private Button btnModif;
    @FXML
    private Button btnSupp;
    
    private Connection cnx;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        TextField_num.setDisable (true);
        Afficher_CMD();
    }    

     public ObservableList<Commande> CommandeList(){
        
        cnx = MyConnection.getInstance().getCnx();
        
        ObservableList<Commande> CommandeList = FXCollections.observableArrayList();
        
        String req = "SELECT * FROM commande";
        
        try{
            
            Statement st = cnx.createStatement();
            ResultSet rs = st.executeQuery(req);
            
            Commande commande;
            
            while(rs.next()){
                
                commande = new Commande(rs.getInt("numCmd"), rs.getFloat("total"),rs.getString("quantite"), rs.getInt("idU"),rs.getInt("idProduit"));   
                
                CommandeList.add(commande);
                
            }
            
        }catch(SQLException e){}
        
        return CommandeList;
        
    }

    private void Afficher_CMD() {
        
        ObservableList<Commande> CommandeList = CommandeList();
        
        numCMD.setCellValueFactory(new PropertyValueFactory<>("numCmd"));
        total.setCellValueFactory(new PropertyValueFactory<>("total"));
        qtite.setCellValueFactory(new PropertyValueFactory<>("quantite"));
        idUser.setCellValueFactory(new PropertyValueFactory<>("idU"));
        idProduit.setCellValueFactory(new PropertyValueFactory<>("idProduit"));
       
        Affichage_cmd.setItems(CommandeList);
    }

    
     public void selectPublication(){
        
        Commande commande = Affichage_cmd.getSelectionModel().getSelectedItem();
        
        int num = Affichage_cmd.getSelectionModel().getSelectedIndex();
        
        if((num-1) < -1)
            return;
        
        TextField_num.setText(String.valueOf(commande.getNumCmd()));
        //DatePicker_Date_PUB.setText(String.(publication.getDate_Pub()));
        TextField_total.setText(String.valueOf(commande.getTotal()));
        TextField_qtite.setText(commande.getQuantite());
        TextField_idu.setText(String.valueOf(commande.getIdU()));
        TextField_idp.setText(String.valueOf(commande.getIdProduit()));
        
        
        
    }
     
    @FXML
    private void Ajouter_CMD(ActionEvent event) {
    }

    @FXML
    private void Modifier_CMD(ActionEvent event) {
    }

    @FXML
    private void Supprimer_CMD(ActionEvent event) {
    }
    
}
